package UAM.Uam;

import java.sql.Connection;
import java.sql.DriverManager;

public class Connect {
	public Connection dbConnect()
	{
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/uam", un="root", pwd = "cdac";
			Connection con = DriverManager.getConnection(url, un, pwd);
			return con;
			
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("exception occured...");
			return null;
		}
	}
			
}


