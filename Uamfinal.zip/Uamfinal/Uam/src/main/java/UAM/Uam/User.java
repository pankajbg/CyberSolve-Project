package UAM.Uam;

import java.io.IOException;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Base64;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;

import com.pojos.in.MyUsers;
import com.sun.jersey.api.view.*;

@Path("/users")
public class User {
    private static Connection c;
    
    String filePath = "D:\\Jersey -B5\\Uam\\src\\main\\webapp\\";

    @Context
    HttpServletRequest servletRequest;
    HttpSession session;

    @GET
    @Path("Connect")
    public String createDbConnection() {
        Connect con = new Connect();
        c = con.dbConnect();
        if (c != null) {
            return "Connected";
        } else {
            return "Something Went Wrong";
        }
    }

    public String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = md.digest(password.getBytes());
            return Base64.getEncoder().encodeToString(hashBytes);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }

    @POST
    @Path("/register")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.APPLICATION_JSON)
    public void addUser(@FormParam("firstname") String firstname, @FormParam("lastname") String lastname,
                        @FormParam("username") String username, @FormParam("password") String userpassword,@FormParam("securityQuestion") String security_question, @FormParam("securityAnswer") String security_answer) {
        try {
            Connect con = new Connect();
            c = con.dbConnect();
            String encryptedPassword = hashPassword(userpassword);
            Statement st = c.createStatement();
            ResultSet rs = st.executeQuery("SELECT user_name FROM user ORDER BY user_id LIMIT 1");

            if (!rs.next()) {
                PreparedStatement ps = c.prepareStatement("insert into user(first_name,last_name,user_name,user_userpassword,user_type,security_question, security_answer) values(?,?,?,?,?,?,?)");
                ps.setString(1, firstname);
                ps.setString(2, lastname);
                ps.setString(3, username);
                ps.setString(4, encryptedPassword);
                ps.setString(5, "admin");
                ps.setString(6, security_question);
                ps.setString(7, security_answer);

                if (ps.executeUpdate() > 0) {
                    return;
                }
            } else {
                String adminUsername = rs.getString("user_name");
                PreparedStatement ps = c.prepareStatement("insert into user(first_name,last_name,user_name,user_userpassword,user_type,manager,security_question,security_answer) values(?,?,?,?,?,?,?,?)");
                ps.setString(1, firstname);
                ps.setString(2, lastname);
                ps.setString(3, username);
                ps.setString(4, encryptedPassword);
                ps.setString(5,"member");
                ps.setString(6, adminUsername);
                ps.setString(7,security_question);
                ps.setString(8, security_answer);
                if (ps.executeUpdate() > 0) {
                    return;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    @POST
    @Path("/login")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public Response loginUser(@FormParam("username") String usrnm, @FormParam("password") String usrpass) {
        Viewable view;
        try {
            Connect con = new Connect();
            Connection c = con.dbConnect();
            Statement st = c.createStatement();
            ResultSet rs = st.executeQuery("select * from user");

            PreparedStatement statement = c.prepareStatement("SELECT * FROM user WHERE user_name = ?");
            statement.setString(1, usrnm);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                String storedPassword = resultSet.getString("user_userpassword");
                String hashedPassword = hashPassword(usrpass);
                String utype = resultSet.getString("user_type");

                if (hashedPassword != null && hashedPassword.equals(storedPassword)) {
                    
                    MyUsers user = new MyUsers(resultSet.getInt(1), resultSet.getString(2), resultSet.getString(3), resultSet.getString(4), resultSet.getString(5), resultSet.getString(6));

                    session = servletRequest.getSession();
                    session.setAttribute("userSession", user);

                    if (utype.equals("member")) {
//                        view = new Viewable("/Member.jsp");
//                        return Response.ok(view).build();
                        URI redirectUri = URI.create("../Member.jsp");
    			        return Response.seeOther(redirectUri).build();
                    } else if (utype.equals("manager")) {
//                        view = new Viewable("/Manager.jsp");
//                        return Response.ok(view).build();
                    	URI redirectUri = URI.create("../Manager.jsp");
    			        return Response.seeOther(redirectUri).build();
                    } else if (utype.equals("admin")) {
//                        view = new Viewable("/Admin.jsp");
//                        return Response.ok(view).build();
                    	URI redirectUri = URI.create("../Admin.jsp");
    			        return Response.seeOther(redirectUri).build();
                    }
                } else {
                    // Invalid credentials
                    String invalidCredentialsHtml = "<html><body>"
                            + "<h1>Invalid credentials. Please try again.</h1>"
                            + "<button onclick=\"window.location.href='http://localhost:8080/Uam/Login.html'\">Go to Login Page</button>"
                            + "</body></html>";
                    return Response.status(Status.UNAUTHORIZED)
                            .entity(invalidCredentialsHtml)
                            .type(MediaType.TEXT_HTML)
                            .build();
                }
            } else {
                // User does not exist
                String nonExistingUserHtml = "<html><body>"
                        + "<h1>User does not exist. Please register or try again.</h1>"
                        + "<button onclick=\"window.location.href='http://localhost:8080/Uam/Login.html'\">Go to Login Page</button>"
                        + "</body></html>";
                return Response.status(Status.UNAUTHORIZED)
                        .entity(nonExistingUserHtml)
                        .type(MediaType.TEXT_HTML)
                        .build();
            }
        } catch (Exception e) {
            // Handle server error due to SQL exception
            String serverErrorHtml = "<html><body>"
                    + "<h1>Server Error Occurred.</h1>"
                    + "<button onclick=\"window.location.href='http://localhost:8080/Uam/Login.html'\">Go to Login Page</button>"
                    + "</body></html>";
            return Response.status(Status.INTERNAL_SERVER_ERROR)
                    .entity(serverErrorHtml)
                    .type(MediaType.TEXT_HTML)
                    .build();
        }
        return null;
    }
}