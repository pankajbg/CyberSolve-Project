package UAM.Uam;

import java.net.URI;
import java.sql.Array;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.NClob;

import com.sun.jersey.api.view.*;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLClientInfoException;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.SQLXML;
import java.sql.Savepoint;
import java.sql.Statement;
import java.sql.Struct;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.Executor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.pojos.in.MyRequests;
import com.pojos.in.MyResources;
import com.pojos.in.MyUsers;

@Path("/requests")
public class Requests {

    private PreparedStatement ps;
    
    @Context
    private HttpServletRequest servletRequest;
    private HttpSession usr;
   
    private MyUsers u =null;
    Viewable view;
    
    public String createRequest(String username, String requirement)
    
	{

    	 try (Connection con = new Connect().dbConnect()) {

			

			ps = con.prepareStatement("select * from requests where requester_source=? and requester_data=? and request_status='pending'");

			ps.setString(1, username);

			ps.setString(2, requirement);

			ResultSet rs = ps.executeQuery();

			if(rs.next())

			{

				return "exists";

			}

			else {

			ps = con.prepareStatement("insert into requests(requester_source, requester_data) values(?, ?)");
             
			ps.setString(1, username);

			ps.setString(2, requirement);

			if(ps.executeUpdate()>0)

			{

				return "requested";

			}

		} }catch (Exception e) {

			e.printStackTrace();

		}

		return "failed";

	}

    
    @GET
	@Path("/logout")
	public String signOutUser()
	{
		try {
			usr = servletRequest.getSession(false);
			if(usr!=null)
			{
				Enumeration<String> sessionAttributes = usr.getAttributeNames();
				while(sessionAttributes.hasMoreElements())
				{
					String attribute = sessionAttributes.nextElement();
					usr.removeAttribute(attribute);
				}
			}
			usr.invalidate();
		} catch (Exception e){
			e.printStackTrace();
		}
		return "<html><head><script>window.location.href='http://localhost:8080/Uam/index.jsp';</script></head><body></body></html>";
	}
    
    @POST
    @Path("/forgetpassword")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.TEXT_HTML)
    public Response forgotPassword(@FormParam("username") String usrname) {
        Connect ec = new Connect();
        Connection connection = ec.dbConnect();
        try {
            String query = "SELECT * FROM user WHERE user_name=?";
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setString(1, usrname);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                HttpSession usersession = servletRequest.getSession();
                usersession.setAttribute("selected", usrname);
                URI redirectUri = URI.create("../SetPassword.jsp");
                return Response.seeOther(redirectUri).build();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        String htmlResponse = "<!DOCTYPE html>\r\n" +
                "<html>\r\n" +
                "  <head>\r\n" +
                "    \r\n" +
                "  </head>\r\n" +
                "  <body>\r\n" +
                "      <h1>No search results</h1>\r\n" +
                "      <a href=\"Login.html\"> Go to Login page</a>\r\n" +
                "      \r\n" +
                "  </body>\r\n" +
                "</html>";
        return Response.ok(htmlResponse).build();
    }

    public String getSecurityQuestion(String username) {
		System.out.println("eneterd secquestion");
        Connect ec = new Connect();
        Connection connection = ec.dbConnect();
        
 
        if (connection != null) {
            try {
            	
                String query = "SELECT security_question from user where user_name=?";
                PreparedStatement preparedStatement = connection.prepareStatement(query);
                preparedStatement.setString(1, username);
               
 
                ResultSet resultSet = preparedStatement.executeQuery();
                
                while(resultSet.next()) {
                	
                	System.out.println(resultSet.getString(1));
                    return resultSet.getString(1);
                }
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
 
        return null;
    }
    
    @POST
    @Path("/setnewpassword")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.TEXT_HTML)
    public Response setNewPassword(@FormParam("answer") String answer, @FormParam("newpassword") String npass) {
        Connect ec = new Connect();
        Connection connection = ec.dbConnect();
        HttpSession usersessn = servletRequest.getSession(false);
        String un = (String) usersessn.getAttribute("selected");
        
        if (connection != null) {
            try {
                String query = "select * from user where user_name=? and security_answer=?";
                PreparedStatement ps = connection.prepareStatement(query);
                ps.setString(1, un);
                ps.setString(2, answer);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    try {
                                               User us = new User();
                        String newhashedpassword = us.hashPassword(npass);
                        String updateQuery = "update user set user_userpassword=? where user_name=?";
                        PreparedStatement p = connection.prepareStatement(updateQuery);
                        p.setString(1, newhashedpassword);
                        p.setString(2, un);
                        if (p.executeUpdate() > 0) {
                            String successResponse = "<!DOCTYPE html>\r\n"
                                    + "<html>\r\n"
                                    + "  <head>\r\n"
                                    + "    \r\n"
                                    + "  </head>\r\n"
                                    + "  <body>\r\n"
                                    + "      <h1>Password Changed Successfully</h1>\r\n"
                                    + "      <a href=\"/Uam/Login.html\"> Go to Login page</a>\r\n"
                                    + "      \r\n"
                                    + "  </body>\r\n"
                                    + "</html>";
                            return Response.ok(successResponse).build();
                        } else {
                            String failureResponse = "<!DOCTYPE html>\r\n"
                                    + "<html>\r\n"
                                    + "  <head>\r\n"
                                    + "    \r\n"
                                    + "  </head>\r\n"
                                    + "  <body>\r\n"
                                    + "      <h1>Could not change password</h1>\r\n"
                                    + "      <a href=\"/Uam/Login.html\"> Go to Login page</a>\r\n"
                                    + "      \r\n"
                                    + "  </body>\r\n"
                                    + "</html>";
                            return Response.ok(failureResponse).build();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        String errorResponse = "<!DOCTYPE html>\r\n"
                + "<html>\r\n"
                + "  <head>\r\n"
                + "    \r\n"
                + "  </head>\r\n"
                + "  <body>\r\n"
                + "      <h1>Error while changing password</h1>\r\n"
                + "      <a href=\"/Uam/Login.html\"> Go to Login page</a>\r\n"
                + "      \r\n"
                + "  </body>\r\n"
                + "</html>";

        return Response.ok(errorResponse).build();
    }

    
    
    
    public List<MyRequests> getAllRequests() {
        List<MyRequests> al = new ArrayList<>();

        try (Connection con = new Connect().dbConnect()) {
            ps = con.prepareStatement("select * from requests where request_status='pending'");
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                al.add(new MyRequests(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4)));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return al;
    }
    
    public List<MyRequests> getUsersByResource(String requestData) {
        List<MyRequests> al = new ArrayList<>();

        try (Connection con = new Connect().dbConnect()) {
            ps = con.prepareStatement("SELECT * FROM requests WHERE requester_data = ? AND request_status = 'approved'");
            ps.setString(1, requestData);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                al.add(new MyRequests(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4)));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return al;
    }

    public List<MyRequests> getResourcesByUser(String requestData) {
        List<MyRequests> al = new ArrayList<>();
        try (Connection con = new Connect().dbConnect()) {
            ps = con.prepareStatement("SELECT * FROM requests WHERE requester_source = ? AND request_status = 'approved' and requester_data not in('admin','manager','member')");
            ps.setString(1, requestData);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                al.add(new MyRequests(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4)));
            }
            
        }catch (Exception e) {
            e.printStackTrace(); 
        }

        return al;
    }
    
   
    public List<String> getAllUsersWithResources() {
        List<String> al = new ArrayList<String>();
        try (Connection con = new Connect().dbConnect()) {
            ps = con.prepareStatement("SELECT distinct(requester_source) from requests where request_status = 'approved'");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                al.add( rs.getString(1));
            }
            
        }catch (Exception e) {
            e.printStackTrace(); 
        }

        return al;
    }
    
  
    public List<MyRequests> getAllRequestsByUser(String user) {
        List<MyRequests> al = new ArrayList<MyRequests>();

        try (Connection con = new Connect().dbConnect()) {
            ps = con.prepareStatement("select * from requests where requester_source=?");
            ps.setString(1, user);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                al.add(new MyRequests(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4)));
            }
            return al;
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }
   
    
    
    
    
    public List<MyUsers> viewAllUsers() {
        List<MyUsers> al = new ArrayList<>();

        try (Connection con = new Connect().dbConnect()) {
            ps = con.prepareStatement("SELECT user_id, user_type, first_name, last_name, user_name, user_userpassword FROM user WHERE user_type != 'admin'");
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                al.add(new MyUsers(
                    rs.getInt("user_id"),
                    rs.getString("user_type"),
                    rs.getString("first_name"),
                    rs.getString("last_name"),
                    rs.getString("user_name"),
                    rs.getString("user_userpassword")
                   
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return al;
    }

    
    @POST
    @Path("/removeuser")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Produces(MediaType.TEXT_HTML)
    public String removeUser(@FormParam("uname") String uname) {
        try (Connection con = new Connect().dbConnect()) {
            PreparedStatement preparedStatement = con.prepareStatement("DELETE FROM user WHERE user_name = ?");
            preparedStatement.setString(1, uname);

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                return generateButtonResponse("User Deleted Successfully", "/Uam/viewAll.jsp");
            } else {
                return generateButtonResponse("User not found", "/Uam/viewAll.jsp");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return generateButtonResponse("Error during User deletion", "/Uam/viewAll.jsp");
        }
    }

    private String generateButtonResponse(String message, String redirectURL) {
        return "<button style=\"background-color: #007bff; color: white; padding: 10px 40px; border: solid; border-radius: 5px; cursor: pointer;\" onclick=\"window.location.href='" + redirectURL + "'\">" + message + "</button>";
    }

    
    @POST
    @Path("/removeresrc")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public String removeResourceFromUser(@FormParam("susr") String username, @FormParam("resrc") String resource) {
        Resources rsrc = new Resources(); // Instantiate Requests here

        try {
            if (rsrc.removeResourceFromUser(username, resource)) {
                return "<button style=\"background-color: #007bff; color: white; padding: 10px 40px; border: solid; border-radius: 5px; cursor: pointer;\" onclick=\"window.location.href='http://localhost:8080/Uam/Admin.jsp'\">Resource removed successfully..Take me Back.</button>";
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return "<button style=\"background-color: #007bff; color: white; padding: 10px 40px; border: solid; border-radius: 5px; cursor: pointer;\" onclick=\"window.location.href='http://localhost:8080/Uam/Admin.jsp'\">Resource cannot be removed..Take me Back.</button>";
    }

    @POST
    @Path("/rmv_resrc_usr")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public String removeResourceFromUser(@FormParam("resrc") String resource) {
    	 Resources rsrc = new Resources();
        try {
            usr =servletRequest.getSession(false);
            u =(MyUsers)usr.getAttribute("userSession");
            
            if(rsrc.removeResourceFromUser(u.getUser_name(),resource))
        	
        	{
                return "<button style=\"background-color: #007bff; color: white; padding: 10px 40px; border: solid; border-radius: 5px; cursor: pointer;\" onclick=\"window.location.href='http://localhost:8080/Uam/Member.jsp'\">Resource removed successfully..Take me Back.</button>";
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return "<button style=\"background-color: #007bff; color: white; padding: 10px 40px; border: solid; border-radius: 5px; cursor: pointer;\" onclick=\"window.location.href='http://localhost:8080/Uam/Member.jsp'\">Resource cannot be removed..Take me Back.</button>";
    }

    
    @POST
    @Path("/rmv_resrc_usr1")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public String removeResourceFromUser1(@FormParam("rmv_resrc") String resource) {
    	 Resources rsrc = new Resources();
        try {
            usr =servletRequest.getSession(false);
            u =(MyUsers)usr.getAttribute("userSession");
            
            if(rsrc.removeResourceFromUser(u.getUser_name(),resource))
        	
        	{
                return "<button style=\"background-color: #007bff; color: white; padding: 10px 40px; border: solid; border-radius: 5px; cursor: pointer;\" onclick=\"window.location.href='http://localhost:8080/Uam/Manager.jsp'\">Resource removed successfully..Take me Back.</button>";
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return "<button style=\"background-color: #007bff; color: white; padding: 10px 40px; border: solid; border-radius: 5px; cursor: pointer;\" onclick=\"window.location.href='http://localhost:8080/Uam/Manager.jsp'\">Resource cannot be removed..Take me Back.</button>";
    }

    
    
    
    @POST
    @Path("/update")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public String updateRequest(@FormParam("username") String usrnm, @FormParam("resource") String resource, @FormParam("status") String status) {
        try (Connection con = new Connect().dbConnect()) {
            // Update requests table
            try (PreparedStatement ps = con.prepareStatement("UPDATE requests SET request_status = ? WHERE requester_source = ? AND requester_data = ?")) {
                ps.setString(1, status);
                ps.setString(2, usrnm);
                ps.setString(3, resource);

                int rowsUpdatedRequests = ps.executeUpdate();

                if (rowsUpdatedRequests > 0) {
                    // Update user table only if the resource matches 'member', 'admin', or 'manager'
                    if ("member".equals(resource) || "admin".equals(resource) || "manager".equals(resource)) {
                        try (PreparedStatement userPs = con.prepareStatement("UPDATE user SET user_type = ? WHERE user_name = ?")) {
                            userPs.setString(1, resource);
                            userPs.setString(2, usrnm);

                            int rowsUpdatedUser = userPs.executeUpdate();

                            if (rowsUpdatedUser > 0) {
                                return "<button style=\"background-color: #007bff; color: white; padding: 10px 40px; border: solid; border-radius: 5px; cursor: pointer;\" onclick=\"window.location.href='http://localhost:8080/Uam/Admin.jsp'\">Request updated successfully..Take me Back.</button>";
                            } else {
                                return "<button style=\"background-color: #007bff; color: white; padding: 10px 40px; border: solid; border-radius: 5px; cursor: pointer;\" onclick=\"window.location.href='http://localhost:8080/Uam/Admin.jsp'\">Failed to update user..Take me Back.</button>";
                            }
                        }
                    } else {
                        return "<button style=\"background-color: #007bff; color: white; padding: 10px 40px; border: solid; border-radius: 5px; cursor: pointer;\" onclick=\"window.location.href='http://localhost:8080/Uam/Admin.jsp'\">Request updated successfully..Take me Back.</button>";
                    }
                }
            } catch (SQLException userUpdateException) {
                userUpdateException.printStackTrace();
                return "<button style=\"background-color: #007bff; color: white; padding: 10px 40px; border: solid; border-radius: 5px; cursor: pointer;\" onclick=\"window.location.href='http://localhost:8080/Uam/Admin.jsp'\">Error occurred while updating user..Take me Back.</button>";
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "<button style=\"background-color: #007bff; color: white; padding: 10px 40px; border: solid; border-radius: 5px; cursor: pointer;\" onclick=\"window.location.href='http://localhost:8080/Uam/Admin.jsp'\">Error occurred while updating request..Take me Back.</button>";
    }

    @POST
    @Path("/update1")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public String updateRequest1(@FormParam("username") String usrnm, @FormParam("resource") String resource, @FormParam("status") String status) {
        try  {
            Resources rqstSrvc =new Resources();
            usr =servletRequest.getSession(false);
            u=(MyUsers)usr.getAttribute("userSession");
            boolean flag =rqstSrvc.updateRequest1(usrnm,resource,status);
            
            if(flag)
            {
            	 return "<button style=\"background-color: #007bff; color: white; padding: 10px 40px; border: solid; border-radius: 5px; cursor: pointer;\" onclick=\"window.location.href='http://localhost:8080/Uam/Manager.jsp'\">Request updated successfully..Take me Back.</button>";	
            }
            
            	
            }catch(Exception e)
        {
            	e.printStackTrace();
        }
        return "<button style=\"background-color: #007bff; color: white; padding: 10px 40px; border: solid; border-radius: 5px; cursor: pointer;\" onclick=\"window.location.href='http://localhost:8080/Uam/Admin.jsp'\">Request  cannot be updated ..Take me Back.</button>";
    }
    @POST
    @Path("/chckresrc")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public Response checkUsersByResource(@FormParam("resourceToCheckUsers") String resource) {
        try {
            HttpSession usr = servletRequest.getSession();
            usr.setAttribute("Resource_Users", resource);
            
                   } catch (Exception e) {
            e.printStackTrace();
        }
        view = new Viewable("/userList.jsp");
        return Response.ok(view).build();
    }
    
    @POST
    @Path("/chckuser")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public Response getResourceByUsers(@FormParam("userToCheckResources") String unm) {
        try {
            HttpSession usr1 = servletRequest.getSession();
            usr1.setAttribute("selectedUser", unm);
            
           
        } catch (Exception e) {
            e.printStackTrace();
        }
        view = new Viewable("/resourceList.jsp");
        return Response.ok(view).build();
        
//        URI redirectUri = URI.create("../resourceList.jsp");
//        return Response.seeOther(redirectUri).build();
    }
    
    
    
    
    @POST
    @Path("/add")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public String addRequest(@FormParam("reqsrc") String resource) {
        try {
            usr = servletRequest.getSession(false);
            u = (MyUsers) usr.getAttribute("userSession");

            if (u != null) {
                Requests rqst = new Requests();
                String result = rqst.createRequest(u.getUser_name(), resource);

                if ("requested".equals(result)) {
                    return "<html><head><script>window.confirm('Request Sent successfully...'); window.location.href='/Uam/Member.jsp';</script></head><body></body></html>";
                } else if ("exists".equals(result)) {
                    return "<html><head><script>window.confirm('Request already pending...\\nWait for request to be approved !!'); window.location.href='/Uam/Member.jsp';</script></head><body></body></html>";
                } else {
                    return "<html><head><script>window.confirm('Request could not be Sent !!'); window.location.href='/Uam/Member.jsp';</script></head><body></body></html>";
                }
            } else {
                return "<html><head><script>window.confirm('User Session not found !!'); window.location.href='/Uam/Member.jsp';</script></head><body></body></html>";
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "<html><head><script>window.confirm('!! Error !!'); window.location.href='/UserAccessManagement/Member.jsp';</script></head><body></body></html>";
    }

    
    @POST
    @Path("/add1")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public String addRequest1(@FormParam("reqrsrc") String resource) {
        try {
            usr = servletRequest.getSession(false);
            u = (MyUsers) usr.getAttribute("userSession");

            if (u != null) {
                Requests rqst = new Requests();
                String result = rqst.createRequest(u.getUser_name(), resource);

                if ("requested".equals(result)) {
                    return "<html><head><script>window.confirm('Request Sent successfully...'); window.location.href='/Uam/Manager.jsp';</script></head><body></body></html>";
                } else if ("exists".equals(result)) {
                    return "<html><head><script>window.confirm('Request already pending...\\nWait for request to be approved !!'); window.location.href='/Uam/Manager.jsp';</script></head><body></body></html>";
                } else {
                    return "<html><head><script>window.confirm('Request could not be Sent !!'); window.location.href='/Uam/Manager.jsp';</script></head><body></body></html>";
                }
            } else {
                return "<html><head><script>window.confirm('User Session not found !!'); window.location.href='/Uam/Manager.jsp';</script></head><body></body></html>";
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "<html><head><script>window.confirm('!! Error !!'); window.location.href='/UserAccessManagement/Manager.jsp';</script></head><body></body></html>";
    }

       
    
    @POST
    @Path("/addtoteam")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public String addUserToTeam(@FormParam("usrs") String username) {
    	 Requests rsrc = new Requests();
        try {
            usr =servletRequest.getSession(false);
            MyUsers manager =(MyUsers)usr.getAttribute("userSession");
            
            if(rsrc.allocateManager(username,manager.getUser_name()))
        	
        	{
                return "<button style=\"background-color: #007bff; color: white; padding: 10px 40px; border: solid; border-radius: 5px; cursor: pointer;\" onclick=\"window.location.href='http://localhost:8080/Uam/Manager.jsp'\">Added to team successfully..Take me Back.</button>";
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return "<button style=\"background-color: #007bff; color: white; padding: 10px 40px; border: solid; border-radius: 5px; cursor: pointer;\" onclick=\"window.location.href='http://localhost:8080/Uam/Manager.jsp'\">Cannot be added to team..Take me Back.</button>";
    }
    
    
    @POST
    @Path("/removefromteam")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public String removeUserFromTeam(@FormParam("usrnm") String username) {
    	 Requests rsrc = new Requests();
        try {
           
            
            if(rsrc.deallocateManager(username))
        	
        	{
                return "<button style=\"background-color: #007bff; color: white; padding: 10px 40px; border: solid; border-radius: 5px; cursor: pointer;\" onclick=\"window.location.href='http://localhost:8080/Uam/Manager.jsp'\">Removed  from team successfully..Take me Back.</button>";
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return "<button style=\"background-color: #007bff; color: white; padding: 10px 40px; border: solid; border-radius: 5px; cursor: pointer;\" onclick=\"window.location.href='http://localhost:8080/Uam/Manager.jsp'\">Cannot be removed from team..Take me Back.</button>";
    }
    
    
    
    
    public String changeRole(String requestor,String requestFor,String newManager)
   {
	   
	   
	   boolean flag = false;
	   
	   try (Connection con = new Connect().dbConnect()) {
           
           ps = con.prepareStatement("select * from requests where requester_source=? and requester_data=? and request_status='pending'");
           ps.setString(1, requestor);
           ps.setString(2, requestFor);
           ResultSet rs = ps.executeQuery();
           if(rs.next())
           {
        	   return "exists";
           }
           else
           {
        	   ps = con.prepareStatement("insert into requests(requester_source,requester_data) values(?,?)");
               ps.setString(1, requestor);
               ps.setString(2, requestFor);
               flag = ps.executeUpdate()>0;
              
               if(flag && newManager!=null)
               {
            	   
            	   ps =con.prepareStatement("insert into requests(requester_source,requester_data)values (?,?)");
            	   ps.setString(1, newManager);
                   ps.setString(2, "manager");
                   
                   if(ps.executeUpdate()>0)
                   {
                	   return "requested";
                   }
               
               }
           }
	  
	   }catch(Exception e)
	   {
		   e.printStackTrace();
	   }
   
   
 return flag?"requested":"failed";
}
    
    
    
    
    
    public List<MyUsers> getAllUsersManager(String manager)
    {
    	   List<MyUsers> a1 = new ArrayList<MyUsers>();

           try (Connection con = new Connect().dbConnect()) {
               ps = con.prepareStatement("select * from user where manager=?");
               ps.setString(1, manager);
               ResultSet rs = ps.executeQuery();

               while (rs.next()) {
                   a1.add(new MyUsers(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4),rs.getString(5),rs.getString(6)));
               }
               return a1;
           } catch (Exception e) {
               e.printStackTrace();
           }

           return null;
       }
    	
    public List<String> getAllUsersNonManager()
    {
    	   List<String> a1 = new ArrayList<String>();

           try (Connection con = new Connect().dbConnect()) {
               ps = con.prepareStatement("select user_name from user where manager is null");
              
               ResultSet rs = ps.executeQuery();

               while (rs.next()) {
                   a1.add(rs.getString(1));
               }
               return a1;
           } catch (Exception e) {
               e.printStackTrace();
           }

           return null;
       }
    	
    

    public boolean allocateManager(String usrnm,String mngr)
    {
    	
    	  try (Connection con = new Connect().dbConnect()) {
              ps = con.prepareStatement("update user set manager=? where user_name=?");
              ps.setString(1, mngr);
              ps.setString(2, usrnm);
              return  ps.executeUpdate()>0 ? true:false;

              
          } catch (Exception e) {
              e.printStackTrace();
          }
    	
		return false;
    	
    }
    
    
    public boolean deallocateManager(String usrnm) {
        try (Connection con = new Connect().dbConnect()) {
            PreparedStatement ps = con.prepareStatement("update user set manager=null where user_name=?");
            ps.setString(1, usrnm);
            return ps.executeUpdate() > 0; // This should return true if the update was successful
        } catch (Exception e) {
            e.printStackTrace(); // Log the exception for debugging purposes
        }
        return false;
    }

    
    
    @POST
    @Path("/roletorequest")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public String roleChangeRequest(
        @FormParam("usr_role_rqst") String role, 
        @FormParam("new_mngr") String newManager) {

        try {
            
            usr = servletRequest.getSession(false);
            u = (MyUsers) usr.getAttribute("userSession");

            if (u != null) {
                Requests rqst = new Requests();
                String result = rqst.changeRole(u.getUser_name(), role, newManager);
                System.out.println(result);

                if ("requested".equals(result)) {
                	 return "<button style=\"background-color: #007bff; color: white; padding: 10px 40px; border: solid; border-radius: 5px; cursor: pointer;\" onclick=\"window.location.href='/Uam/Manager.jsp'\">Request sent successfully..Take me Back.</button>";
                } else if ("exists".equals(result)) {
                    return "<html><head><script>alert('Existing request is pending...\\nYou can make only one request for " + role + " at a time !!'); window.location.href='/Uam/Manager.jsp';</script></head><body></body></html>";
                } else {
                    return "<html><head><script>window.confirm('Request could not be Sent !!'); window.location.href='/Uam/Manager.jsp';</script></head><body></body></html>";
                }
            } else {
                                return "<html><head><script>window.confirm('User session not found !!'); window.location.href='/Uam/Member.jsp';</script></head><body></body></html>";
            }
        } catch (Exception e) {
            e.printStackTrace();
                       return "<html><head><script>window.confirm('!! Error: " + e.getMessage() + " !!'); window.location.href='/Uam/Member.jsp';</script></head><body></body></html>";
        }
    }


@POST
@Path("/roletorequest1")
@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
public String roleChangeRequest1(
    @FormParam("usr_role_rqst") String role, 
    @FormParam("new_mngr") String newManager) {

    try {
        
        usr = servletRequest.getSession(false);
        u = (MyUsers) usr.getAttribute("userSession");

        if (u != null) {
            Requests rqst = new Requests();
            String result = rqst.changeRole(u.getUser_name(), role, newManager);
            System.out.println(result);

            if ("requested".equals(result)) {
            	 return "<button style=\"background-color: #007bff; color: white; padding: 10px 40px; border: solid; border-radius: 5px; cursor: pointer;\" onclick=\"window.location.href='/Uam/Member.jsp'\">Request sent successfully..Take me Back.</button>";
            } else if ("exists".equals(result)) {
                return "<html><head><script>alert('Existing request is pending...\\nYou can make only one request for " + role + " at a time !!'); window.location.href='/Uam/Member.jsp';</script></head><body></body></html>";
            } else {
                return "<html><head><script>window.confirm('Request could not be Sent !!'); window.location.href='/Uam/Member.jsp';</script></head><body></body></html>";
            }
        } else {
                            return "<html><head><script>window.confirm('User session not found !!'); window.location.href='/Uam/Member.jsp';</script></head><body></body></html>";
        }
    } catch (Exception e) {
        e.printStackTrace();
                   return "<html><head><script>window.confirm('!! Error: " + e.getMessage() + " !!'); window.location.href='/Uam/Member.jsp';</script></head><body></body></html>";
    }
}
}









