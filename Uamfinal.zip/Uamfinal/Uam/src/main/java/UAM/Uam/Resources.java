package UAM.Uam;

import java.net.URI;
import java.net.URLDecoder;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.sun.jersey.api.view.Viewable;

@Path("/resources")
public class Resources {
	
	@Context
    private HttpServletRequest servletRequest;
    Viewable view;
	private PreparedStatement ps;

	
    @POST
    @Path("/addResource")
    public String addResource(@FormParam("addResource") String resrc) {
        try (Connection con = new Connect().dbConnect()) {
        	            if (con != null) {
                

                PreparedStatement ps = con.prepareStatement("INSERT INTO resources(resource_name) VALUES(?)");
                ps.setString(1, resrc);
                int rowsAffected = ps.executeUpdate();
                if (rowsAffected > 0) {
                	return "<button style=\"background-color: #007bff; color: white; padding: 10px 40px; border: solid; border-radius: 5px; cursor: pointer;\" onclick=\"window.location.href='http://localhost:8080/Uam/Admin.jsp'\">Resource Added Successfully..Take me Back</button>";
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return "<button style=\"background-color: #007bff; color: white; padding: 10px 40px; border: solid; border-radius: 5px; cursor: pointer;\" onclick=\"window.location.href='http://localhost:8080/Uam/Admin.jsp'\">Fail to add..Take me Back.</button>";
    }

    @POST
    @Path("/removeResource")
    public String removeResource(@FormParam("removeResource") String resrc) {
        try (Connection con = new Connect().dbConnect()) {
            if (con != null) {
                PreparedStatement ps = con.prepareStatement("DELETE FROM resources WHERE resource_name = ?");
                ps.setString(1, resrc);
                int rowsAffected = ps.executeUpdate();
                if (rowsAffected > 0) {
                    return "<button style=\"background-color: #007bff; color: white; padding: 10px 40px; border: solid; border-radius: 5px; cursor: pointer;\" onclick=\"window.location.href='http://localhost:8080/Uam/Admin.jsp'\">Resource Removed Successfully..Take me Back</button>";
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return "<button style=\"background-color: #007bff; color: white; padding: 10px 40px; border: solid; border-radius: 5px; cursor: pointer;\" onclick=\"window.location.href='http://localhost:8080/Uam/Admin.jsp'\">Failed to remove resource..Take me Back</button>";
    }
    
    
    
    @POST
    @Path("/user")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public Response getResourcesByUser(@FormParam("rmvresrcusr")String unm) {
        
        try  {
        	
        	 HttpSession usr1 = servletRequest.getSession();
             usr1.setAttribute("slcdUsr", unm);
           
            
        }catch (Exception e) {
            e.printStackTrace(); 
        }
//         view = new Viewable("/Admin.jsp");
//        return Response.ok(view).build();
        
        URI redirectUri = URI.create("../Admin.jsp");
        return Response.seeOther(redirectUri).build();
    }
    
   
    public boolean removeResourceFromUser(String username, String resource)
    {
    	
    	 try (Connection con = new Connect().dbConnect()){
    		 ps = con.prepareStatement("delete from requests where requester_source=?  and requester_data=?");
    		 ps.setString(1, username);
    		 ps.setString(2, resource);
    		 
    		return ps.executeUpdate()>0?true:false;
    	 }
    	 catch(Exception e)
    	 {
    		 e.printStackTrace();
    	 }
    	
    	
		return false;
    	
    }
    public boolean removeResourceFromUser1(String username, String resource)
    {
    	
    	 try (Connection con = new Connect().dbConnect()){
    		 ps = con.prepareStatement("delete from requests where requester_source=?  and requester_data=?");
    		 ps.setString(1, username);
    		 ps.setString(2, resource);
    		 
    		return ps.executeUpdate()>0?true:false;
    	 }
    	 catch(Exception e)
    	 {
    		 e.printStackTrace();
    	 }
    	
    	
		return false;
    	
    }
    
    
    public List<String> resourcesToRequest(String user) {
        List<String> resources = new ArrayList<String>();
        try (Connection con = new Connect().dbConnect()) {
        	ps = con.prepareStatement("SELECT resource_name from resources where resource_name not in (select requester_data from requests where  requester_source=? and request_status = 'approved')");

            ps.setString(1, user);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                resources.add( rs.getString(1));
            }
            
        }catch (Exception e) {
            e.printStackTrace(); 
        }

        return resources;
    }
    
    
    
    public List<String> getResourcesByUser1(String username) {
        List<String> a1 = new ArrayList<String>();
        try (Connection con = new Connect().dbConnect()) {
            ps = con.prepareStatement("SELECT requester_data from requests where requester_source=?  and request_status = 'approved' and requester_data not in('manager','member','admin')");
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                a1.add(rs.getString(1));
                
            }
            System.out.println(a1);
        } catch (Exception e) {
            e.printStackTrace(); 
        }
        return a1;
    }
    
    
    public boolean updateRequest1(String username, String requirement, String status) {
        try (Connection con = new Connect().dbConnect()) {
            boolean flag = false;

            
            try (PreparedStatement ps = con.prepareStatement("update requests set request_status=? where requester_source=? and requester_data=?")) {
                ps.setString(1, status);
                ps.setString(2, username);
                ps.setString(3, requirement);
                flag = ps.executeUpdate() > 0;

                
                if (flag && "approved".equals(status) && ("manager".equals(requirement) || "admin".equals(requirement))) {
                    // Prepare the update statement for users
                    try (PreparedStatement psUpdateUser = con.prepareStatement("update users set user_type=? where user_name=?")) {
                        psUpdateUser.setString(1, requirement);
                        psUpdateUser.setString(2, username);
                        flag = psUpdateUser.executeUpdate() > 0;
                    }
                }
            }
            return flag;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

     
    

}
    
  

