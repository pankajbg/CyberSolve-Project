package com.pojos.in;

public class MyResources {
	
	private int resource_id;
	@Override
	public String toString() {
		return "MyResources [resource_id=" + resource_id + ", resource_name=" + resource_name + "]";
	}
	private String resource_name;
	public MyResources(int resource_id, String resource_name) {
		super();
		this.resource_id = resource_id;
		this.resource_name = resource_name;
	}
	public int getResource_id() {
		return resource_id;
	}
	public void setResource_id(int resource_id) {
		this.resource_id = resource_id;
	}
	public String getResource_name() {
		return resource_name;
	}
	public void setResource_name(String resource_name) {
		this.resource_name = resource_name;
	}
	

}
