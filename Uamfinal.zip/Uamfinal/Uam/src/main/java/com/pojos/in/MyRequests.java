package com.pojos.in;

public class MyRequests {

	private int request_id;
	private String requester_source;
	private String requester_data;
	private String request_status;
	public MyRequests(int request_id, String requester_source, String requester_data, String request_status)
			 {
		super();
		this.request_id = request_id;
		this.requester_source = requester_source;
		this.requester_data = requester_data;
		this.request_status = request_status;
		
	}
	
	
	public MyRequests() {
		super();
	}


	public int getRequest_id() {
		return request_id;
	}
	public void setRequest_id(int request_id) {
		this.request_id = request_id;
	}
	public String getRequester_source() {
		return requester_source;
	}
	public void setRequester_source(String requester_source) {
		this.requester_source = requester_source;
	}
	public String getRequester_data() {
		return requester_data;
	}
	public void setRequester_data(String requester_data) {
		this.requester_data = requester_data;
	}
	public String getRequest_status() {
		return request_status;
	}
	public void setRequest_status(String request_status) {
		this.request_status = request_status;
	}


	@Override
	public String toString() {
		return "MyRequests [request_id=" + request_id + ", requester_source=" + requester_source + ", requester_data="
				+ requester_data + ", request_status=" + request_status + "]";
	}
			
	
	
}
