package com.pojos.in;

public class MyUsers {
	
	private int user_id;
	private String user_type;
	private String  first_name;
	private String last_name;
	private String user_name;
	private String user_userpassword;
	
	public MyUsers( int user_id,String first_name, String last_name, String user_name,
			String user_userpassword) {
		super();
		this.user_id =user_id;
		this.first_name = first_name;
		this.last_name = last_name;
		this.user_name = user_name;
		this.user_userpassword = user_userpassword;
	}

	public MyUsers(int user_id, String user_type, String first_name, String last_name, String user_name, String user_userpassword) {
		super();
		this.user_id = user_id;
		this.user_type =user_type;
		this.first_name = first_name;
		this.last_name = last_name;
		this.user_name = user_name;
		this.user_userpassword = user_userpassword;
	}

	public MyUsers() {
		super();
	}

	public int getUser_id() {
		return user_id;
	}

	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}

	public String getUser_type() {
		return user_type;
	}

	public void setUser_type(String user_type) {
		this.user_type = user_type;
	}

	public String getFirst_name() {
		return first_name;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	public String getLast_name() {
		return last_name;
	}

	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}

	public String getUser_userpassword() {
		return user_userpassword;
	}

	public void setUser_userpassword(String user_userpassword) {
		this.user_userpassword = user_userpassword;
	}

	@Override
	public String toString() {
		return "MyUsers [user_id=" + user_id + ", user_type=" + user_type + ", first_name=" + first_name
				+ ", last_name=" + last_name + ", user_name=" + user_name + ", user_userpassword=" + user_userpassword
				+ "]";
	}

	

}
